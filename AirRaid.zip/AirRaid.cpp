/*

AERSP 424 Project: AIR RAID
Group Members: Darrian Petrakis, Joeseph Peters, and Jordon Zakarevicz

*/

#include <iostream>
#include "GameManager.h"

using namespace std;

int main()
{
	GameManager::start();	// start the game 
	GameManager::runGame();	// runs the game
	
	return 0;
}